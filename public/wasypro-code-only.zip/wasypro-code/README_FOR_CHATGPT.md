# TỔNG QUAN HỆ THỐNG PHÂN PHỐI BÁN HÀNG WASYPRO (CTV & NPP)

Dự án này là nền tảng quản trị phân phối đa cấp gồm:
1. **Frontend**: React 18, TypeScript, Tailwind CSS, Vite.
   - Thư mục: `src/`
   - Quản lý CTV: `src/components/admin/AdminCTVManagement.tsx`
   - Quản lý NPP: `src/components/admin/AdminNppManagement.tsx`
   - Quản lý Đơn hàng NPP: `src/components/admin/AdminNppPurchases.tsx`
   - Sơ đồ tuyến dưới NPP: `src/components/admin/AdminNppDownlineModal.tsx`
   - Quản lý Đơn hàng chung: `src/components/admin/AdminOrders.tsx`

2. **Backend**: Node.js, Express, Prisma ORM, SQLite.
   - Thư mục: `server/`
   - Logic chính: `server/index.js`
   - Database schema: `server/prisma/schema.prisma`

3. **Cơ chế nghiệp vụ trọng tâm cần đánh giá**:
   - Hệ thống cấp bậc: AMBASSADOR (Đại sứ), MANAGER (Trưởng nhóm), DIRECTOR (Quản lý).
   - Cơ chế bảo trợ tuyến trên (Sponsor / Upline) và tuyến dưới (Downline).
   - Điều kiện thăng hạng (ví dụ: Giới thiệu đủ 5 F1 gồm cả CTV và NPP).
   - Cơ chế tính chiết khấu, hoa hồng và duyệt đơn hàng NPP/CTV.
